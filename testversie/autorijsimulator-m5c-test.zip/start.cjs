const http=require('node:http');
const fs=require('node:fs/promises');
const path=require('node:path');
const {spawn}=require('node:child_process');
const folder=path.join(__dirname,'simulator');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
const server=http.createServer(async(req,res)=>{
 const pathname=new URL(req.url,'http://localhost').pathname;
 if(pathname!=='/'&&!/^\/assets\/[\w.-]+$/.test(pathname)){res.writeHead(404).end();return;}
 const file=path.join(folder,pathname==='/'?'index.html':pathname.slice(1));
 try{
  const content=await fs.readFile(file);
  res.writeHead(200,{'Content-Type':types[path.extname(file)]??'application/octet-stream'}).end(content);
 }catch{res.writeHead(404).end();}
});
server.on('error',error=>console.error('Starten mislukt:',error.message));
server.listen(4173,'127.0.0.1',()=>{
 const url='http://127.0.0.1:4173/';
 console.log('Simulator geopend op '+url+' . Sluit dit venster om te stoppen.');
 const browser=spawn('cmd.exe',['/d','/c','start','',''+url],{windowsHide:true,stdio:'ignore'});
 browser.on('error',()=>console.log('Open het adres hierboven in je browser.'));
});
