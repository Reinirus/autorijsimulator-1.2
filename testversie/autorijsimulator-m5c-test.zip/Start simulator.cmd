@echo off
cd /d "%~dp0"
where node >nul 2>&1 || (echo Node.js is nodig om de simulator te starten. & pause & exit /b 1)
node start.cjs
pause
